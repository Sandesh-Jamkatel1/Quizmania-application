// Common JavaScript functions for the QuizMania application

// Toggle mobile menu
document.addEventListener('DOMContentLoaded', function() {
    // Add any initialization code here
    console.log('QuizMania application loaded');
});

// Quiz timer functionality
function startQuizTimer(duration, displayElement) {
    let timer = duration;
    let minutes, seconds;
    
    const interval = setInterval(function() {
        minutes = parseInt(timer / 60, 10);
        seconds = parseInt(timer % 60, 10);
        
        minutes = minutes < 10 ? "0" + minutes : minutes;
        seconds = seconds < 10 ? "0" + seconds : seconds;
        
        displayElement.textContent = minutes + ":" + seconds;
        
        if (--timer < 0) {
            clearInterval(interval);
            // Submit the quiz automatically when time is up
            document.getElementById('quiz-form').submit();
        }
    }, 1000);
    
    return interval;
}

// Option selection in quiz
function selectOption(optionElement) {
    // Remove selected class from all options in the same question
    const questionDiv = optionElement.closest('.question');
    const options = questionDiv.querySelectorAll('.option');
    
    options.forEach(option => {
        option.classList.remove('selected');
    });
    
    // Add selected class to clicked option
    optionElement.classList.add('selected');
    
    // Update hidden input value
    const questionId = questionDiv.dataset.questionId;
    const optionValue = optionElement.dataset.optionValue;
    document.querySelector(`input[name="answer[${questionId}]"]`).value = optionValue;
}

// Chart.js initialization for admin dashboard
function initAdminChart(chartData) {
    if (!chartData || !document.getElementById('adminChart')) return;
    
    const ctx = document.getElementById('adminChart').getContext('2d');
    
    new Chart(ctx, {
        type: 'line',
        data: {
            labels: chartData.labels,
            datasets: [{
                label: 'Active Users',
                data: chartData.activeUsers,
                backgroundColor: 'rgba(0, 123, 255, 0.2)',
                borderColor: 'rgba(0, 123, 255, 1)',
                borderWidth: 2,
                tension: 0.3
            }, {
                label: 'New Registrations',
                data: chartData.newUsers,
                backgroundColor: 'rgba(40, 167, 69, 0.2)',
                borderColor: 'rgba(40, 167, 69, 1)',
                borderWidth: 2,
                tension: 0.3
            }]
        },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            scales: {
                y: {
                    beginAtZero: true
                }
            }
        }
    });
}

// User dashboard chart
function initUserChart(chartData) {
    if (!chartData || !document.getElementById('userChart')) return;
    
    const ctx = document.getElementById('userChart').getContext('2d');
    
    new Chart(ctx, {
        type: 'bar',
        data: {
            labels: chartData.categories,
            datasets: [{
                label: 'Score Percentage',
                data: chartData.scores,
                backgroundColor: [
                    'rgba(255, 99, 132, 0.5)',
                    'rgba(54, 162, 235, 0.5)',
                    'rgba(255, 206, 86, 0.5)',
                    'rgba(75, 192, 192, 0.5)',
                    'rgba(153, 102, 255, 0.5)',
                    'rgba(255, 159, 64, 0.5)'
                ],
                borderColor: [
                    'rgba(255, 99, 132, 1)',
                    'rgba(54, 162, 235, 1)',
                    'rgba(255, 206, 86, 1)',
                    'rgba(75, 192, 192, 1)',
                    'rgba(153, 102, 255, 1)',
                    'rgba(255, 159, 64, 1)'
                ],
                borderWidth: 1
            }]
        },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            scales: {
                y: {
                    beginAtZero: true,
                    max: 100
                }
            }
        }
    });
}