<?php
// Database connection parameters
$host = "localhost";
$username = "root";
$password = "";

// Create connection
$conn = new mysqli($host, $username, $password);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Read SQL file
$sql = file_get_contents('database.sql');

// Execute multi query
if ($conn->multi_query($sql)) {
    echo "Database and tables created successfully!<br>";
    echo "You can now access the application at <a href='index.php'>index.php</a>";
} else {
    echo "Error creating database: " . $conn->error;
}

$conn->close();
?>