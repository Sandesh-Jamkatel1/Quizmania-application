<?php
session_start();
require_once 'includes/db_connect.php';
require_once 'includes/functions.php';

// Redirect if not logged in
if (!is_user_logged_in()) {
    redirect_with_message("login.php", "Please log in to access your dashboard", "danger");
}

// Get user data
$user_id = $_SESSION['user_id'];
$user = get_user_by_id($conn, $user_id);

// Get user quiz statistics
$stats = get_user_quiz_stats($conn, $user_id);

// Get recent quiz attempts
$recent_attempts = get_recent_quiz_attempts($conn, $user_id);

// Prepare chart data
$chart_data = [
    'categories' => [],
    'scores' => []
];

foreach ($stats['category_stats'] as $category_stat) {
    $chart_data['categories'][] = $category_stat['category'];
    $chart_data['scores'][] = $category_stat['average_score'];
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Dashboard - QuizMania</title>
    <link rel="stylesheet" href="css/style.css">
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
</head>
<body>
    <?php include 'includes/header.php'; ?>
    
    <main>
        <div class="container dashboard-container">
            <div class="dashboard-header">
                <h2>Welcome, <?php echo htmlspecialchars($_SESSION['user_name']); ?>!</h2>
                <p>Here's your quiz performance overview</p>
            </div>
            
            <div class="dashboard-stats">
                <div class="stat-card">
                    <h3>Total Quizzes Taken</h3>
                    <div class="stat-value"><?php echo $stats['total_quizzes']; ?></div>
                </div>
                
                <div class="stat-card">
                    <h3>Average Score</h3>
                    <div class="stat-value"><?php echo $stats['average_score']; ?>%</div>
                </div>
                
                <div class="stat-card">
                    <h3>Last Played</h3>
                    <div class="stat-value">
                        <?php echo $stats['last_played'] ? date('M d, Y', strtotime($stats['last_played'])) : 'Never'; ?>
                    </div>
                </div>
            </div>
            
            <div class="dashboard-card">
                <h3>Performance by Category</h3>
                <div style="height: 300px;">
                    <canvas id="userChart"></canvas>
                </div>
            </div>
            
            <div class="recent-activity">
                <h3>Recent Quiz Attempts</h3>
                <?php if (empty($recent_attempts)): ?>
                    <p>You haven't taken any quizzes yet. <a href="categories.php">Start a quiz now!</a></p>
                <?php else: ?>
                    <table class="activity-table">
                        <thead>
                            <tr>
                                <th>Date</th>
                                <th>Category</th>
                                <th>Score</th>
                                <th>Time Taken</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php foreach ($recent_attempts as $attempt): ?>
                                <tr>
                                    <td><?php echo date('M d, Y H:i', strtotime($attempt['attempt_date'])); ?></td>
                                    <td><?php echo htmlspecialchars($attempt['category_name']); ?></td>
                                    <td><?php echo $attempt['score'] . '/' . $attempt['total_questions'] . ' (' . round(($attempt['score'] / $attempt['total_questions']) * 100, 2) . '%)'; ?></td>
                                    <td><?php echo format_time_taken($attempt['time_taken']); ?></td>
                                </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                <?php endif; ?>
            </div>
        </div>
    </main>
    
    <?php include 'includes/footer.php'; ?>
    <script src="js/script.js"></script>
    <script>
        document.addEventListener('DOMContentLoaded', function() {
            // Initialize user chart
            const chartData = {
                categories: <?php echo json_encode($chart_data['categories']); ?>,
                scores: <?php echo json_encode($chart_data['scores']); ?>
            };
            
            initUserChart(chartData);
        });
    </script>
</body>
</html>