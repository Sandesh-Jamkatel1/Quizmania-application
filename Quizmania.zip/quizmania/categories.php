<?php
session_start();
require_once 'includes/db_connect.php';
require_once 'includes/functions.php';

// Get the search query if it's set
$search_query = isset($_GET['search']) ? trim($_GET['search']) : '';

// Modify the query to filter categories based on the search query
if (!empty($search_query)) {
    $sql = "SELECT * FROM categories WHERE name LIKE ? ORDER BY name ASC";
    $stmt = $conn->prepare($sql);
    $search_term = "%" . $search_query . "%";
    $stmt->bind_param("s", $search_term);
} else {
    // Fetch all categories if no search query
    $sql = "SELECT * FROM categories ORDER BY name ASC";
    $stmt = $conn->prepare($sql);
}

$stmt->execute();
$result = $stmt->get_result();
$categories = $result->fetch_all(MYSQLI_ASSOC);

// Category images (you can replace these with actual images)
$category_images = [
    'HTML' => 'https://cdn.pixabay.com/photo/2017/08/05/11/16/logo-2582748_960_720.png',
    'CSS' => 'https://cdn.pixabay.com/photo/2017/08/05/11/16/logo-2582747_960_720.png',
    'JavaScript' => 'https://cdn.pixabay.com/photo/2015/04/23/17/41/javascript-736400_960_720.png',
    'jQuery' => 'https://cdn.pixabay.com/photo/2015/04/23/17/41/javascript-736400_960_720.png',
    'DSA' => 'https://cdn.pixabay.com/photo/2018/05/08/08/44/artificial-intelligence-3382507_960_720.jpg',
    'PHP' => 'https://upload.wikimedia.org/wikipedia/commons/thumb/2/27/PHP-logo.svg/1200px-PHP-logo.svg.png',
    'C' => 'https://www.khmer168.com/wp-content/uploads/2024/01/c-tutorial-for-beginners.png',
    'Java' => 'https://cdn.pixabay.com/photo/2018/03/23/09/27/java-3257007_960_720.jpg',
    'MySQL' => 'https://cdn.pixabay.com/photo/2016/06/17/22/02/mysql-1462791_960_720.png',
    'Python' => 'https://cdn.pixabay.com/photo/2017/08/30/00/01/python-2695432_960_720.jpg',
    'Ruby' => 'https://cdn.pixabay.com/photo/2018/07/06/16/47/ruby-3517042_960_720.jpg',
    'Swift' => 'https://cdn.pixabay.com/photo/2020/10/28/08/31/swift-5696981_960_720.jpg',
    'Go' => 'https://cdn.pixabay.com/photo/2018/07/29/15/57/go-3574042_960_720.jpg',
    'Kotlin' => 'https://cdn.pixabay.com/photo/2019/02/26/17/47/kotlin-4014922_960_720.jpg',
    'Rust' => 'https://cdn.pixabay.com/photo/2020/07/09/07/47/rust-5386818_960_720.jpg',
    'TypeScript' => 'https://cdn.pixabay.com/photo/2019/02/26/18/33/typescript-4014956_960_720.jpg',
    'React' => 'https://cdn.pixabay.com/photo/2018/05/22/16/21/react-3415179_960_720.jpg',
    'Angular' => 'https://cdn.pixabay.com/photo/2019/10/24/14/24/angular-4577023_960_720.jpg',
    'Node.js' => 'https://cdn.pixabay.com/photo/2019/05/22/10/04/node-4201415_960_720.jpg',
    'Vue.js' => 'https://cdn.pixabay.com/photo/2018/11/23/13/35/vuejs-3836961_960_720.jpg',
];
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Quiz Categories - QuizMania</title>
    <link rel="stylesheet" href="css/style.css">
    <style>
        /* CSS for category images and layout */
        .category-card {
            background: #fff;
            border-radius: 10px;
            overflow: hidden;
            box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
            transition: transform 0.3s ease;
        }

        .category-card:hover {
            transform: translateY(-10px);
        }

        .category-img {
            height: 200px;
            background-size: cover;
            background-position: center;
        }
        .category-img img{
            height: 200%;
        }

        .category-content {
            padding: 20px;
        }

        .category-content h3 {
            margin-top: 0;
            font-size: 1.5rem;
            color: #333;
        }

        .category-content p {
            color: #777;
        }

        .categories-grid {
            display: grid;
            grid-template-columns: repeat(auto-fill, minmax(300px, 1fr));
            gap: 20px;
        }

        /* Search form styling */
        .search-form {
            margin-bottom: 20px;
            display: flex;
            justify-content: center;
            align-items: center;
            gap: 10px;
        }

        .search-input {
            padding: 10px;
            font-size: 16px;
            border: 2px solid #ccc;
            border-radius: 5px;
            width: 250px;
            max-width: 100%;
            outline: none;
        }

        .search-input:focus {
            border-color: #0056b3;
        }

        .search-btn {
            padding: 10px 20px;
            font-size: 16px;
            background-color: #0056b3;
            color: white;
            border: none;
            border-radius: 5px;
            cursor: pointer;
        }

        .search-btn:hover {
            background-color: #00408d;
        }

        @media (max-width: 768px) {
            .search-form {
                flex-direction: column;
                align-items: stretch;
            }

            .search-input, .search-btn {
                width: 100%;
            }
        }
    </style>
</head>
<body>
    <?php include 'includes/header.php'; ?>
    
    <main>
        <div class="container categories-container">
            <h2>Choose a Quiz Category</h2>

            <!-- Search Form -->
            <form action="categories.php" method="get" class="search-form">
                <input type="text" name="search" value="<?php echo htmlspecialchars($search_query); ?>" placeholder="Search for categories..." class="search-input">
                <button type="submit" class="search-btn">Search</button>
            </form>
            
            <?php if (empty($categories)): ?>
                <p>No categories found. Please check back later.</p>
            <?php else: ?>
                <div class="categories-grid">
                    <?php foreach ($categories as $category): ?>
                        <div class="category-card">
                            <div class="category-img" style="background-image: url('<?php echo isset($category_images[$category['name']]) ? $category_images[$category['name']] : 'https://cdn.pixabay.com/photo/2016/11/23/14/37/coding-1853305_960_720.jpg'; ?>');"></div>
                            <div class="category-content">
                                <h3><?php echo htmlspecialchars($category['name']); ?></h3>
                                <p><?php echo htmlspecialchars($category['description']); ?></p>
                                <a href="quiz_setup.php?category_id=<?php echo $category['id']; ?>" class="btn btn-primary">Start Quiz</a>
                            </div>
                        </div>
                    <?php endforeach; ?>
                </div>
            <?php endif; ?>
        </div>
    </main>
    
    <?php include 'includes/footer.php'; ?>
    <script src="js/script.js"></script>
</body>
</html>
