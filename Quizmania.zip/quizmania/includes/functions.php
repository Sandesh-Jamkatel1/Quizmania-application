<?php
// Common functions for the QuizMania application

// Function to sanitize user input
function sanitize_input($data) {
    $data = trim($data);
    $data = stripslashes($data);
    $data = htmlspecialchars($data);
    return $data;
}

// Function to check if email already exists
function email_exists($conn, $email) {
    $sql = "SELECT id FROM users WHERE email = ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("s", $email);
    $stmt->execute();
    $result = $stmt->get_result();
    return $result->num_rows > 0;
}

// Function to check if admin email already exists
function admin_email_exists($conn, $email) {
    $sql = "SELECT id FROM admins WHERE email = ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("s", $email);
    $stmt->execute();
    $result = $stmt->get_result();
    return $result->num_rows > 0;
}

// Function to check if category already exists (case insensitive)
function category_exists($conn, $category_name) {
    $sql = "SELECT id FROM categories WHERE LOWER(name) = LOWER(?)";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("s", $category_name);
    $stmt->execute();
    $result = $stmt->get_result();
    return $result->num_rows > 0;
}

// Function to get user by ID
function get_user_by_id($conn, $user_id) {
    $sql = "SELECT * FROM users WHERE id = ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("i", $user_id);
    $stmt->execute();
    $result = $stmt->get_result();
    return $result->fetch_assoc();
}

// Function to get admin by ID
function get_admin_by_id($conn, $admin_id) {
    $sql = "SELECT * FROM admins WHERE id = ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("i", $admin_id);
    $stmt->execute();
    $result = $stmt->get_result();
    return $result->fetch_assoc();
}

// Function to get all categories
function get_all_categories($conn) {
    $sql = "SELECT * FROM categories ORDER BY name";
    $result = $conn->query($sql);
    $categories = [];
    
    if ($result->num_rows > 0) {
        while ($row = $result->fetch_assoc()) {
            $categories[] = $row;
        }
    }
    
    return $categories;
}

// Function to get category by ID
function get_category_by_id($conn, $category_id) {
    $sql = "SELECT * FROM categories WHERE id = ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("i", $category_id);
    $stmt->execute();
    $result = $stmt->get_result();
    return $result->fetch_assoc();
}

// Function to get questions by category ID
function get_questions_by_category($conn, $category_id, $limit = null) {
    $sql = "SELECT * FROM questions WHERE category_id = ?";
    
    if ($limit !== null && is_numeric($limit)) {
        $sql .= " ORDER BY RAND() LIMIT ?";
        $stmt = $conn->prepare($sql);
        $stmt->bind_param("ii", $category_id, $limit);
    } else {
        $stmt = $conn->prepare($sql);
        $stmt->bind_param("i", $category_id);
    }
    
    $stmt->execute();
    $result = $stmt->get_result();
    $questions = [];
    
    if ($result->num_rows > 0) {
        while ($row = $result->fetch_assoc()) {
            $questions[] = $row;
        }
    }
    
    return $questions;
}

// Function to get options for a question
function get_options_for_question($conn, $question_id) {
    $sql = "SELECT * FROM options WHERE question_id = ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("i", $question_id);
    $stmt->execute();
    $result = $stmt->get_result();
    $options = [];
    
    if ($result->num_rows > 0) {
        while ($row = $result->fetch_assoc()) {
            $options[] = $row;
        }
    }
    
    return $options;
}

// Function to get correct answer for a question
function get_correct_answer($conn, $question_id) {
    $sql = "SELECT correct_option FROM questions WHERE id = ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("i", $question_id);
    $stmt->execute();
    $result = $stmt->get_result();
    $row = $result->fetch_assoc();
    return $row['correct_option'];
}

// Function to record quiz attempt
function record_quiz_attempt($conn, $user_id, $category_id, $score, $total_questions, $time_taken) {
    $sql = "INSERT INTO quiz_attempts (user_id, category_id, score, total_questions, time_taken, attempt_date) VALUES (?, ?, ?, ?, ?, NOW())";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("iiiii", $user_id, $category_id, $score, $total_questions, $time_taken);
    return $stmt->execute();
}

// Function to get user quiz statistics
function get_user_quiz_stats($conn, $user_id) {
    $stats = [
        'total_quizzes' => 0,
        'average_score' => 0,
        'last_played' => null,
        'category_stats' => []
    ];
    
    // Get total quizzes and average score
    $sql = "SELECT COUNT(*) as total_quizzes, AVG(score * 100 / total_questions) as average_score, MAX(attempt_date) as last_played FROM quiz_attempts WHERE user_id = ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("i", $user_id);
    $stmt->execute();
    $result = $stmt->get_result();
    $row = $result->fetch_assoc();
    
    $stats['total_quizzes'] = $row['total_quizzes'];
    $stats['average_score'] = round($row['average_score'], 2);
    $stats['last_played'] = $row['last_played'];
    
    // Get category stats
    $sql = "SELECT c.name, COUNT(*) as attempts, AVG(qa.score * 100 / qa.total_questions) as average_score 
            FROM quiz_attempts qa 
            JOIN categories c ON qa.category_id = c.id 
            WHERE qa.user_id = ? 
            GROUP BY qa.category_id";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("i", $user_id);
    $stmt->execute();
    $result = $stmt->get_result();
    
    while ($row = $result->fetch_assoc()) {
        $stats['category_stats'][] = [
            'category' => $row['name'],
            'attempts' => $row['attempts'],
            'average_score' => round($row['average_score'], 2)
        ];
    }
    
    return $stats;
}

// Function to get recent quiz attempts for a user
function get_recent_quiz_attempts($conn, $user_id, $limit = 5) {
    $sql = "SELECT qa.*, c.name as category_name 
            FROM quiz_attempts qa 
            JOIN categories c ON qa.category_id = c.id 
            WHERE qa.user_id = ? 
            ORDER BY qa.attempt_date DESC 
            LIMIT ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("ii", $user_id, $limit);
    $stmt->execute();
    $result = $stmt->get_result();
    $attempts = [];
    
    while ($row = $result->fetch_assoc()) {
        $attempts[] = $row;
    }
    
    return $attempts;
}

// Function to get active users
function get_active_users($conn) {
    $sql = "SELECT u.*, MAX(qa.attempt_date) as last_activity 
            FROM users u 
            LEFT JOIN quiz_attempts qa ON u.id = qa.user_id 
            GROUP BY u.id 
            HAVING last_activity > DATE_SUB(NOW(), INTERVAL 24 HOUR) OR last_activity IS NULL 
            ORDER BY last_activity DESC";
    $result = $conn->query($sql);
    $users = [];
    
    if ($result->num_rows > 0) {
        while ($row = $result->fetch_assoc()) {
            $users[] = $row;
        }
    }
    
    return $users;
}

// Function to get admin dashboard data
function get_admin_dashboard_data($conn) {
    $data = [
        'total_users' => 0,
        'total_quizzes' => 0,
        'total_questions' => 0,
        'active_users' => 0,
        'category_stats' => [],
        'recent_activity' => []
    ];
    
    // Get total users
    $sql = "SELECT COUNT(*) as total FROM users";
    $result = $conn->query($sql);
    $row = $result->fetch_assoc();
    $data['total_users'] = $row['total'];
    
    // Get total quiz attempts
    $sql = "SELECT COUNT(*) as total FROM quiz_attempts";
    $result = $conn->query($sql);
    $row = $result->fetch_assoc();
    $data['total_quizzes'] = $row['total'];
    
    // Get total questions
    $sql = "SELECT COUNT(*) as total FROM questions";
    $result = $conn->query($sql);
    $row = $result->fetch_assoc();
    $data['total_questions'] = $row['total'];
    
    // Get active users (last 24 hours)
    $sql = "SELECT COUNT(DISTINCT user_id) as total FROM quiz_attempts WHERE attempt_date > DATE_SUB(NOW(), INTERVAL 24 HOUR)";
    $result = $conn->query($sql);
    $row = $result->fetch_assoc();
    $data['active_users'] = $row['total'];
    
    // Get category stats
    $sql = "SELECT c.name, COUNT(qa.id) as attempts 
            FROM categories c 
            LEFT JOIN quiz_attempts qa ON c.id = qa.category_id 
            GROUP BY c.id 
            ORDER BY attempts DESC";
    $result = $conn->query($sql);
    
    while ($row = $result->fetch_assoc()) {
        $data['category_stats'][] = [
            'category' => $row['name'],
            'attempts' => $row['attempts']
        ];
    }
    
    // Get recent activity
    $sql = "SELECT qa.*, u.name as user_name, c.name as category_name 
            FROM quiz_attempts qa 
            JOIN users u ON qa.user_id = u.id 
            JOIN categories c ON qa.category_id = c.id 
            ORDER BY qa.attempt_date DESC 
            LIMIT 10";
    $result = $conn->query($sql);
    
    while ($row = $result->fetch_assoc()) {
        $data['recent_activity'][] = $row;
    }
    
    return $data;
}

// Function to format time in seconds to minutes and seconds
function format_time_taken($seconds) {
    $minutes = floor($seconds / 60);
    $seconds = $seconds % 60;
    return sprintf("%02d:%02d", $minutes, $seconds);
}

// Function to check if user is logged in
function is_user_logged_in() {
    return isset($_SESSION['user_id']);
}

// Function to check if admin is logged in
function is_admin_logged_in() {
    return isset($_SESSION['admin_id']);
}

// Function to redirect with message
function redirect_with_message($url, $message, $type = 'success') {
    $_SESSION['message'] = $message;
    $_SESSION['message_type'] = $type;
    header("Location: $url");
    exit;
}

// Function to display message
function display_message() {
    if (isset($_SESSION['message'])) {
        $message = $_SESSION['message'];
        $type = $_SESSION['message_type'];
        unset($_SESSION['message']);
        unset($_SESSION['message_type']);
        return "<div class='alert alert-$type'>$message</div>";
    }
    return '';
}

// Function to count questions in a category
function count_questions_in_category($conn, $category_id) {
    $sql = "SELECT COUNT(*) as total FROM questions WHERE category_id = ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("i", $category_id);
    $stmt->execute();
    $result = $stmt->get_result();
    $row = $result->fetch_assoc();
    return $row['total'];
}

// Function to validate question data
function validate_question_data($question_text, $options, $correct_option) {
    $errors = [];
    
    // Check if question is empty
    if (empty($question_text)) {
        $errors[] = "Question text cannot be empty";
    }
    
    // Check if all options are provided
    foreach ($options as $index => $option) {
        if (empty($option)) {
            $errors[] = "Option " . ($index + 1) . " cannot be empty";
        }
    }
    
    // Check if options are unique
    if (count(array_unique($options)) !== count($options)) {
        $errors[] = "All options must be unique";
    }
    
    // Check if correct option is valid
    if ($correct_option < 0 || $correct_option >= count($options)) {
        $errors[] = "Invalid correct option selected";
    }
    
    return $errors;
}