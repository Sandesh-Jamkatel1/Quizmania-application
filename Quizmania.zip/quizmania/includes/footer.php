<footer>
    <div class="container">
        <div class="footer-content">
            <div class="footer-section">
                <h3>QuizMania</h3>
                <p>Test your knowledge with our interactive quizzes.</p>
            </div>
            <div class="footer-section">
                <h3>Quick Links</h3>
                <ul>
                    <li><a href="index.php">Home</a></li>
                    <li><a href="categories.php">Categories</a></li>
                    <?php if(isset($_SESSION['user_id'])): ?>
                        <li><a href="dashboard.php">Dashboard</a></li>
                    <?php else: ?>
                        <li><a href="login.php">Login</a></li>
                        <li><a href="register.php">Register</a></li>
                    <?php endif; ?>
                </ul>
            </div>
            <div class="footer-section">
                <h3>Connect With Us</h3>
                <div class="social-links">
                    <a href="https://www.facebook.com/sandesh.jamarkatel.16/" class="social-link">Facebook</a>
                    <a href="https://github.com/Sandesh-Jamkatel1/" class="social-link">Github</a>
                    <a href="https://np.linkedin.com/in/sandesh-jamkatel-554973237" class="social-link">LinkedIn</a>
                </div>
            </div>
        </div>
        <div class="footer-bottom">
            <p>&copy; <?php echo date('Y'); ?> QuizMania. All rights reserved.</p>
        </div>
    </div>
</footer>