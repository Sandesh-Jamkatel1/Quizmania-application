<?php
session_start();
require_once '../includes/db_connect.php';
require_once '../includes/functions.php';

// Redirect if not logged in
if (!is_admin_logged_in()) {
    redirect_with_message("login.php", "Please log in to access the admin dashboard", "danger");
}

$errors = [];
$success = false;

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Get form data
    $name = sanitize_input($_POST['name']);
    $description = sanitize_input($_POST['description']);
    
    // Validate form data
    if (empty($name)) {
        $errors[] = "Category name is required";
    } elseif (category_exists($conn, $name)) {
        $errors[] = "Category with this name already exists";
    }
    
    if (empty($description)) {
        $errors[] = "Category description is required";
    }
    
    // If no errors, add the category
    if (empty($errors)) {
        // Insert category into database
        $sql = "INSERT INTO categories (name, description, created_at) VALUES (?, ?, NOW())";
        $stmt = $conn->prepare($sql);
        $stmt->bind_param("ss", $name, $description);
        
        if ($stmt->execute()) {
            $success = true;
            $name = '';
            $description = '';
        } else {
            $errors[] = "Failed to add category: " . $conn->error;
        }
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Add Category - QuizMania Admin</title>
    <link rel="stylesheet" href="../css/style.css">
</head>
<body>
    <div class="admin-container">
        <?php include 'includes/sidebar.php'; ?>
        
        <div class="admin-content">
            <div class="admin-header">
                <h2>Add Category</h2>
            </div>
            
            <div class="admin-card">
                <?php if ($success): ?>
                    <div class="alert alert-success">
                        Category added successfully!
                    </div>
                <?php endif; ?>
                
                <?php if (!empty($errors)): ?>
                    <div class="alert alert-danger">
                        <ul>
                            <?php foreach ($errors as $error): ?>
                                <li><?php echo $error; ?></li>
                            <?php endforeach; ?>
                        </ul>
                    </div>
                <?php endif; ?>
                
                <form action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>" method="post" class="admin-form">
                    <div class="form-group">
                        <label for="name">Category Name</label>
                        <input type="text" id="name" name="name" class="form-control" value="<?php echo isset($name) ? $name : ''; ?>" required>
                    </div>
                    
                    <div class="form-group">
                        <label for="description">Category Description</label>
                        <textarea id="description" name="description" class="form-control" rows="4" required><?php echo isset($description) ? $description : ''; ?></textarea>
                    </div>
                    
                    <button type="submit" class="form-btn">Add Category</button>
                </form>
            </div>
        </div>
    </div>
    
    <script src="../js/script.js"></script>
</body>
</html>