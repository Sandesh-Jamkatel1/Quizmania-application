<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Sidebar</title>
    <style>
        .logout{
            background-color: #000;
            color: #000;
            
        }
    </style>
</head>
<body>

<div class="admin-sidebar">
    <div class="logo">
        <a href="dashboard.php">QuizMania Admin</a>
    </div>
    
    <nav>
        <ul>
            <li><a href="dashboard.php" class="<?php echo basename($_SERVER['PHP_SELF']) == 'dashboard.php' ? 'active' : ''; ?>">Dashboard</a></li>
            <li><a href="add_category.php" class="<?php echo basename($_SERVER['PHP_SELF']) == 'add_category.php' ? 'active' : ''; ?>">Add Category</a></li>
            <li><a href="manage_categories.php" class="<?php echo basename($_SERVER['PHP_SELF']) == 'manage_categories.php' ? 'active' : ''; ?>">Manage Categories</a></li>
            <li><a href="add_question.php" class="<?php echo basename($_SERVER['PHP_SELF']) == 'add_question.php' ? 'active' : ''; ?>">Add Question</a></li>
            <li><a href="manage_questions.php" class="<?php echo basename($_SERVER['PHP_SELF']) == 'manage_questions.php' ? 'active' : ''; ?>">Manage Questions</a></li>
            <li><a href="active_users.php" class="<?php echo basename($_SERVER['PHP_SELF']) == 'active_users.php' ? 'active' : ''; ?>">Active Users</a></li>
            <li><a href="user_reports.php" class="<?php echo basename($_SERVER['PHP_SELF']) == 'user_reports.php' ? 'active' : ''; ?>">User Reports</a></li>
            <li><a class="logout" href="logout.php">Logout</a></li>
        </ul>
    </nav>
</div>

</body>
</html>
