<?php
session_start();
require_once '../includes/db_connect.php';
require_once '../includes/functions.php';

// Redirect if not logged in
if (!is_admin_logged_in()) {
    redirect_with_message("login.php", "Please log in to access the admin dashboard", "danger");
}

// Get all categories
$categories = get_all_categories($conn);

// Get question details if ID is passed
$question_id = isset($_GET['id']) ? intval($_GET['id']) : 0;
$errors = [];
$success = false;
$question_data = null;

if ($question_id > 0) {
    // Get the question from the database
    $sql = "SELECT * FROM questions WHERE id = ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("i", $question_id);
    $stmt->execute();
    $result = $stmt->get_result();
    $question_data = $result->fetch_assoc();
    
    if (!$question_data) {
        $errors[] = "Question not found!";
    }
}

// Process form submission
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Get form data
    $category_id = isset($_POST['category_id']) ? intval($_POST['category_id']) : 0;
    $question_text = sanitize_input($_POST['question_text']);
    $options = [
        sanitize_input($_POST['option1']),
        sanitize_input($_POST['option2']),
        sanitize_input($_POST['option3']),
        sanitize_input($_POST['option4'])
    ];
    $correct_option = isset($_POST['correct_option']) ? intval($_POST['correct_option']) : -1;
    
    // Validate form data
    if ($category_id <= 0) {
        $errors[] = "Please select a category";
    }
    
    // Validate question data
    $validation_errors = validate_question_data($question_text, $options, $correct_option);
    if (!empty($validation_errors)) {
        $errors = array_merge($errors, $validation_errors);
    }
    
    // If no errors, update the question
    if (empty($errors)) {
        $sql = "UPDATE questions SET category_id = ?, question_text = ?, option1 = ?, option2 = ?, option3 = ?, option4 = ?, correct_option = ? WHERE id = ?";
        $stmt = $conn->prepare($sql);
        
        // Corrected bind_param: 
        // 'i' for integer values (category_id, correct_option, question_id)
        // 's' for string values (question_text, options, etc.)
        $stmt->bind_param("issssssi", $category_id, $question_text, $options[0], $options[1], $options[2], $options[3], $correct_option, $question_id);
        
        if ($stmt->execute()) {
            $success = true;
            $question_text = '';
            $options = ['', '', '', ''];
            $correct_option = -1;
        } else {
            $errors[] = "Failed to update question: " . $conn->error;
        }
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Edit Question - QuizMania Admin</title>
    <link rel="stylesheet" href="../css/style.css">
</head>
<body>
    <div class="admin-container">
        <?php include 'includes/sidebar.php'; ?>
        
        <div class="admin-content">
            <div class="admin-header">
                <h2>Edit Question</h2>
            </div>
            
            <div class="admin-card">
                <?php if ($success): ?>
                    <div class="alert alert-success">
                        Question updated successfully!
                    </div>
                <?php endif; ?>
                
                <?php if (!empty($errors)): ?>
                    <div class="alert alert-danger">
                        <ul>
                            <?php foreach ($errors as $error): ?>
                                <li><?php echo $error; ?></li>
                            <?php endforeach; ?>
                        </ul>
                    </div>
                <?php endif; ?>
                
                <?php if (empty($categories)): ?>
                    <div class="alert alert-danger">
                        <p>No categories available. <a href="add_category.php">Add a category</a> first to add questions.</p>
                    </div>
                <?php else: ?>
                    <?php if ($question_data): ?>
                        <form action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"] . '?id=' . $question_id); ?>" method="post" class="admin-form">
                            <div class="form-group">
                                <label for="category_id">Category</label>
                                <select id="category_id" name="category_id" class="form-control" required>
                                    <option value="">Select Category</option>
                                    <?php foreach ($categories as $category): ?>
                                        <option value="<?php echo $category['id']; ?>" <?php echo $category['id'] == $question_data['category_id'] ? 'selected' : ''; ?>>
                                            <?php echo htmlspecialchars($category['name']); ?>
                                        </option>
                                    <?php endforeach; ?>
                                </select>
                            </div>
                            
                            <div class="form-group">
                                <label for="question_text">Question</label>
                                <textarea id="question_text" name="question_text" class="form-control" rows="3" required><?php echo isset($question_data['question_text']) ? $question_data['question_text'] : ''; ?></textarea>
                            </div>
                            
                            <div class="form-group">
                                <label for="option1">Option 1</label>
                                <input type="text" id="option1" name="option1" class="form-control" value="<?php echo isset($question_data['option1']) ? $question_data['option1'] : ''; ?>" required>
                            </div>
                            
                            <div class="form-group">
                                <label for="option2">Option 2</label>
                                <input type="text" id="option2" name="option2" class="form-control" value="<?php echo isset($question_data['option2']) ? $question_data['option2'] : ''; ?>" required>
                            </div>
                            
                            <div class="form-group">
                                <label for="option3">Option 3</label>
                                <input type="text" id="option3" name="option3" class="form-control" value="<?php echo isset($question_data['option3']) ? $question_data['option3'] : ''; ?>" required>
                            </div>
                            
                            <div class="form-group">
                                <label for="option4">Option 4</label>
                                <input type="text" id="option4" name="option4" class="form-control" value="<?php echo isset($question_data['option4']) ? $question_data['option4'] : ''; ?>" required>
                            </div>
                            
                            <div class="form-group">
                                <label>Correct Option</label>
                                <div class="options">
                                    <div class="form-check">
                                        <input type="radio" id="correct_option_0" name="correct_option" value="0" class="form-check-input" <?php echo $question_data['correct_option'] == 0 ? 'checked' : ''; ?> required>
                                        <label for="correct_option_0">Option 1</label>
                                    </div>
                                    <div class="form-check">
                                        <input type="radio" id="correct_option_1" name="correct_option" value="1" class="form-check-input" <?php echo $question_data['correct_option'] == 1 ? 'checked' : ''; ?>>
                                        <label for="correct_option_1">Option 2</label>
                                    </div>
                                    <div class="form-check">
                                        <input type="radio" id="correct_option_2" name="correct_option" value="2" class="form-check-input" <?php echo $question_data['correct_option'] == 2 ? 'checked' : ''; ?>>
                                        <label for="correct_option_2">Option 3</label>
                                    </div>
                                    <div class="form-check">
                                        <input type="radio" id="correct_option_3" name="correct_option" value="3" class="form-check-input" <?php echo $question_data['correct_option'] == 3 ? 'checked' : ''; ?>>
                                        <label for="correct_option_3">Option 4</label>
                                    </div>
                                </div>
                            </div>
                            
                            <button type="submit" class="form-btn">Update Question</button>
                        </form>
                    <?php else: ?>
                        <p>Question not found.</p>
                    <?php endif; ?>
                <?php endif; ?>
            </div>
        </div>
    </div>
    
    <script src="../js/script.js"></script>
</body>
</html>
