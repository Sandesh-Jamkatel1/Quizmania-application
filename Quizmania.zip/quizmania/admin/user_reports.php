<?php
session_start();
require_once '../includes/db_connect.php';
require_once '../includes/functions.php';

// Redirect if not logged in
if (!is_admin_logged_in()) {
    redirect_with_message("login.php", "Please log in to access the admin dashboard", "danger");
}

// Check if user ID is provided
$user_id = isset($_GET['user_id']) ? intval($_GET['user_id']) : 0;
$user = null;
$quiz_attempts = [];

if ($user_id > 0) {
    // Get user data
    $user = get_user_by_id($conn, $user_id);
    
    if ($user) {
        // Get user's quiz attempts
        $sql = "SELECT qa.*, c.name as category_name 
                FROM quiz_attempts qa 
                JOIN categories c ON qa.category_id = c.id 
                WHERE qa.user_id = ? 
                ORDER BY qa.attempt_date DESC";
        $stmt = $conn->prepare($sql);
        $stmt->bind_param("i", $user_id);
        $stmt->execute();
        $result = $stmt->get_result();
        
        while ($row = $result->fetch_assoc()) {
            $quiz_attempts[] = $row;
        }
    }
}

// Get all users for dropdown
$sql = "SELECT id, name, email FROM users ORDER BY name";
$result = $conn->query($sql);
$all_users = [];

if ($result->num_rows > 0) {
    while ($row = $result->fetch_assoc()) {
        $all_users[] = $row;
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>User Reports - QuizMania Admin</title>
    <link rel="stylesheet" href="../css/style.css">
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
</head>
<body>
    <div class="admin-container">
        <?php include 'includes/sidebar.php'; ?>
        
        <div class="admin-content">
            <div class="admin-header">
                <h2>User Reports</h2>
            </div>
            
            <div class="admin-card">
                <div class="filter-form">
                    <form action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>" method="get">
                        <div class="form-group" style="display: flex; gap: 10px; align-items: center;">
                            <label for="user_id">Select User:</label>
                            <select id="user_id" name="user_id" class="form-control" onchange="this.form.submit()">
                                <option value="0">Select User</option>
                                <?php foreach ($all_users as $u): ?>
                                    <option value="<?php echo $u['id']; ?>" <?php echo $user_id == $u['id'] ? 'selected' : ''; ?>>
                                        <?php echo htmlspecialchars($u['name']) . ' (' . htmlspecialchars($u['email']) . ')'; ?>
                                    </option>
                                <?php endforeach; ?>
                            </select>
                        </div>
                    </form>
                </div>
                
                <?php if (!$user): ?>
                    <p>Please select a user to view their reports.</p>
                <?php else: ?>
                    <div class="user-info">
                        <h3>User Information</h3>
                        <p><strong>Name:</strong> <?php echo htmlspecialchars($user['name']); ?></p>
                        <p><strong>Email:</strong> <?php echo htmlspecialchars($user['email']); ?></p>
                        <p><strong>Registered:</strong> <?php echo date('M d, Y', strtotime($user['created_at'])); ?></p>
                        <p><strong>Last Login:</strong> <?php echo $user['last_login'] ? date('M d, Y H:i', strtotime($user['last_login'])) : 'Never'; ?></p>
                    </div>
                    
                    <?php if (empty($quiz_attempts)): ?>
                        <p>This user has not taken any quizzes yet.</p>
                    <?php else: ?>
                        <div class="user-stats">
                            <h3>Quiz Statistics</h3>
                            <div style="height: 300px; margin-bottom: 30px;">
                                <canvas id="userPerformanceChart"></canvas>
                            </div>
                            
                            <h3>Quiz Attempts</h3>
                            <table class="admin-table">
                                <thead>
                                    <tr>
                                        <th>Date</th>
                                        <th>Category</th>
                                        <th>Score</th>
                                        <th>Time Taken</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php foreach ($quiz_attempts as $attempt): ?>
                                        <tr>
                                            <td><?php echo date('M d, Y H:i', strtotime($attempt['attempt_date'])); ?></td>
                                            <td><?php echo htmlspecialchars($attempt['category_name']); ?></td>
                                            <td><?php echo $attempt['score'] . '/' . $attempt['total_questions'] . ' (' . round(($attempt['score'] / $attempt['total_questions']) * 100, 2) . '%)'; ?></td>
                                            <td><?php echo format_time_taken($attempt['time_taken']); ?></td>
                                        </tr>
                                    <?php endforeach; ?>
                                </tbody>
                            </table>
                        </div>
                    <?php endif; ?>
                <?php endif; ?>
            </div>
        </div>
    </div>
    
    <script src="../js/script.js"></script>
    <?php if ($user && !empty($quiz_attempts)): ?>
        <script>
            document.addEventListener('DOMContentLoaded', function() {
                // Prepare data for chart
                const categories = [];
                const scores = [];
                const attempts = [];
                
                <?php
                // Get category stats for the user
                $category_stats = [];
                $sql = "SELECT c.name, COUNT(*) as attempts, AVG(qa.score * 100 / qa.total_questions) as average_score 
                        FROM quiz_attempts qa 
                        JOIN categories c ON qa.category_id = c.id 
                        WHERE qa.user_id = ? 
                        GROUP BY qa.category_id";
                $stmt = $conn->prepare($sql);
                $stmt->bind_param("i", $user_id);
                $stmt->execute();
                $result = $stmt->get_result();
                
                while ($row = $result->fetch_assoc()) {
                    $category_stats[] = $row;
                }
                ?>
                
                <?php foreach ($category_stats as $stat): ?>
                    categories.push('<?php echo addslashes($stat['name']); ?>');
                    scores.push(<?php echo round($stat['average_score'], 2); ?>);
                    attempts.push(<?php echo $stat['attempts']; ?>);
                <?php endforeach; ?>
                
                // Create chart
                const ctx = document.getElementById('userPerformanceChart').getContext('2d');
                new Chart(ctx, {
                    type: 'bar',
                    data: {
                        labels: categories,
                        datasets: [{
                            label: 'Average Score (%)',
                            data: scores,
                            backgroundColor: 'rgba(54, 162, 235, 0.5)',
                            borderColor: 'rgba(54, 162, 235, 1)',
                            borderWidth: 1,
                            yAxisID: 'y'
                        }, {
                            label: 'Number of Attempts',
                            data: attempts,
                            backgroundColor: 'rgba(255, 99, 132, 0.5)',
                            borderColor: 'rgba(255, 99, 132, 1)',
                            borderWidth: 1,
                            type: 'line',
                            yAxisID: 'y1'
                        }]
                    },
                    options: {
                        responsive: true,
                        maintainAspectRatio: false,
                        scales: {
                            y: {
                                beginAtZero: true,
                                max: 100,
                                title: {
                                    display: true,
                                    text: 'Score Percentage'
                                }
                            },
                            y1: {
                                beginAtZero: true,
                                position: 'right',
                                grid: {
                                    drawOnChartArea: false
                                },
                                title: {
                                    display: true,
                                    text: 'Number of Attempts'
                                }
                            }
                        }
                    }
                });
            });
        </script>
    <?php endif; ?>
</body>
</html>