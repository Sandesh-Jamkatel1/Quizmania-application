<?php
session_start();
require_once '../includes/db_connect.php';
require_once '../includes/functions.php';

// Redirect if already logged in
if (is_admin_logged_in()) {
    header("Location: dashboard.php");
    exit;
}

// Redirect to login page
header("Location: login.php");
exit;
?>