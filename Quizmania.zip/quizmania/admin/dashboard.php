<?php
session_start();
require_once '../includes/db_connect.php';
require_once '../includes/functions.php';

// Redirect if not logged in
if (!is_admin_logged_in()) {
    redirect_with_message("login.php", "Please log in to access the admin dashboard", "danger");
}

// Get admin data
$admin_id = $_SESSION['admin_id'];
$admin = get_admin_by_id($conn, $admin_id);

// Get dashboard data
$dashboard_data = get_admin_dashboard_data($conn);

// Get active users
$active_users = get_active_users($conn);

// Prepare chart data for the last 7 days
$chart_data = [
    'labels' => [],
    'activeUsers' => [],
    'newUsers' => []
];

for ($i = 6; $i >= 0; $i--) {
    $date = date('Y-m-d', strtotime("-$i days"));
    $chart_data['labels'][] = date('M d', strtotime("-$i days"));
    
    // Get active users for this day
    $sql = "SELECT COUNT(DISTINCT user_id) as count FROM quiz_attempts WHERE DATE(attempt_date) = ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("s", $date);
    $stmt->execute();
    $result = $stmt->get_result();
    $row = $result->fetch_assoc();
    $chart_data['activeUsers'][] = $row['count'];
    
    // Get new users for this day
    $sql = "SELECT COUNT(*) as count FROM users WHERE DATE(created_at) = ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("s", $date);
    $stmt->execute();
    $result = $stmt->get_result();
    $row = $result->fetch_assoc();
    $chart_data['newUsers'][] = $row['count'];
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Dashboard - QuizMania</title>
    <link rel="stylesheet" href="../css/style.css">
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
</head>
<body>
    <div class="admin-container">
        <?php include 'includes/sidebar.php'; ?>
        
        <div class="admin-content">
            <div class="admin-header">
                <h2>Dashboard</h2>
                <div>
                    <span>Welcome, <?php echo htmlspecialchars($_SESSION['admin_name']); ?>!</span>
                </div>
            </div>
            
            <div class="admin-stats">
                <div class="admin-stat">
                    <h3>Total Users</h3>
                    <div class="stat-value"><?php echo $dashboard_data['total_users']; ?></div>
                </div>
                
                <div class="admin-stat">
                    <h3>Active Users (24h)</h3>
                    <div class="stat-value"><?php echo $dashboard_data['active_users']; ?></div>
                </div>
                
                <div class="admin-stat">
                    <h3>Total Quizzes Taken</h3>
                    <div class="stat-value"><?php echo $dashboard_data['total_quizzes']; ?></div>
                </div>
                
                <div class="admin-stat">
                    <h3>Total Questions</h3>
                    <div class="stat-value"><?php echo $dashboard_data['total_questions']; ?></div>
                </div>
            </div>
            
            <div class="admin-card">
                <h3>User Activity (Last 7 Days)</h3>
                <div style="height: 300px;">
                    <canvas id="adminChart"></canvas>
                </div>
            </div>
            
            <div class="admin-card">
                <h3>Category Statistics</h3>
                <?php if (empty($dashboard_data['category_stats'])): ?>
                    <p>No categories available yet. <a href="add_category.php">Add a category</a> to get started.</p>
                <?php else: ?>
                    <table class="admin-table">
                        <thead>
                            <tr>
                                <th>Category</th>
                                <th>Quiz Attempts</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php foreach ($dashboard_data['category_stats'] as $category): ?>
                                <tr>
                                    <td><?php echo htmlspecialchars($category['category']); ?></td>
                                    <td><?php echo $category['attempts']; ?></td>
                                </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                <?php endif; ?>
            </div>
            
            <div class="admin-card">
                <h3>Recent Activity</h3>
                <?php if (empty($dashboard_data['recent_activity'])): ?>
                    <p>No recent activity.</p>
                <?php else: ?>
                    <table class="admin-table">
                        <thead>
                            <tr>
                                <th>Date</th>
                                <th>User</th>
                                <th>Category</th>
                                <th>Score</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php foreach ($dashboard_data['recent_activity'] as $activity): ?>
                                <tr>
                                    <td><?php echo date('M d, Y H:i', strtotime($activity['attempt_date'])); ?></td>
                                    <td><?php echo htmlspecialchars($activity['user_name']); ?></td>
                                    <td><?php echo htmlspecialchars($activity['category_name']); ?></td>
                                    <td><?php echo $activity['score'] . '/' . $activity['total_questions'] . ' (' . round(($activity['score'] / $activity['total_questions']) * 100, 2) . '%)'; ?></td>
                                </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                <?php endif; ?>
            </div>
        </div>
    </div>
    
    <script src="../js/script.js"></script>
    <script>
        document.addEventListener('DOMContentLoaded', function() {
            // Initialize admin chart
            const chartData = {
                labels: <?php echo json_encode($chart_data['labels']); ?>,
                activeUsers: <?php echo json_encode($chart_data['activeUsers']); ?>,
                newUsers: <?php echo json_encode($chart_data['newUsers']); ?>
            };
            
            initAdminChart(chartData);
        });
    </script>
</body>
</html>