<?php
session_start();
require_once '../includes/db_connect.php';
require_once '../includes/functions.php';

// Redirect if not logged in
if (!is_admin_logged_in()) {
    redirect_with_message("login.php", "Please log in to access the admin dashboard", "danger");
}

// Get all categories for filter
$categories = get_all_categories($conn);

// Get selected category for filter
$filter_category = isset($_GET['category']) ? intval($_GET['category']) : 0;

// Get questions based on filter
if ($filter_category > 0) {
    $sql = "SELECT q.*, c.name as category_name FROM questions q JOIN categories c ON q.category_id = c.id WHERE q.category_id = ? ORDER BY q.id DESC";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("i", $filter_category);
    $stmt->execute();
    $result = $stmt->get_result();
} else {
    $sql = "SELECT q.*, c.name as category_name FROM questions q JOIN categories c ON q.category_id = c.id ORDER BY q.id DESC";
    $result = $conn->query($sql);
}

$questions = [];
if ($result->num_rows > 0) {
    while ($row = $result->fetch_assoc()) {
        $questions[] = $row;
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Manage Questions - QuizMania Admin</title>
    <link rel="stylesheet" href="../css/style.css">
</head>
<body>
    <div class="admin-container">
        <?php include 'includes/sidebar.php'; ?>
        
        <div class="admin-content">
            <div class="admin-header">
                <h2>Manage Questions</h2>
                <a href="add_question.php" class="btn btn-primary">Add New Question</a>
            </div>
            
            <div class="admin-card">
                <div class="filter-form">
                    <form action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>" method="get">
                        <div class="form-group" style="display: flex; gap: 10px; align-items: center;">
                            <label for="category">Filter by Category:</label>
                            <select id="category" name="category" class="form-control" onchange="this.form.submit()">
                                <option value="0">All Categories</option>
                                <?php foreach ($categories as $category): ?>
                                    <option value="<?php echo $category['id']; ?>" <?php echo $filter_category == $category['id'] ? 'selected' : ''; ?>>
                                        <?php echo htmlspecialchars($category['name']); ?>
                                    </option>
                                <?php endforeach; ?>
                            </select>
                        </div>
                    </form>
                </div>
                
                <?php 
                // Display message if set
                echo display_message();
                
                if (empty($questions)): 
                ?>
                    <p>No questions available. <a href="add_question.php">Add a question</a> to get started.</p>
                <?php else: ?>
                    <table class="admin-table">
                        <thead>
                            <tr>
                                <th>ID</th>
                                <th>Category</th>
                                <th>Question</th>
                                <th>Options</th>
                                <th>Correct</th>
                                <th>Actions</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php foreach ($questions as $question): ?>
                                <tr>
                                    <td><?php echo $question['id']; ?></td>
                                    <td><?php echo htmlspecialchars($question['category_name']); ?></td>
                                    <td><?php echo htmlspecialchars($question['question_text']); ?></td>
                                    <td>
                                        <ol>
                                            <li><?php echo htmlspecialchars($question['option1']); ?></li>
                                            <li><?php echo htmlspecialchars($question['option2']); ?></li>
                                            <li><?php echo htmlspecialchars($question['option3']); ?></li>
                                            <li><?php echo htmlspecialchars($question['option4']); ?></li>
                                        </ol>
                                    </td>
                                    <td><?php echo $question['correct_option'] + 1; ?></td>
                                    <td>
                                        <a href="edit_question.php?id=<?php echo $question['id']; ?>" class="btn btn-secondary">Edit</a>
                                    </td>
                                </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                <?php endif; ?>
            </div>
        </div>
    </div>
    
    <script src="../js/script.js"></script>
</body>
</html>