<?php
session_start();
require_once '../includes/db_connect.php';
require_once '../includes/functions.php';

// Redirect if already logged in
if (is_admin_logged_in()) {
    header("Location: dashboard.php");
    exit;
}

$errors = [];

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Get form data
    $email = sanitize_input($_POST['email']);
    $password = $_POST['password'];
    $remember = isset($_POST['remember']) ? true : false;
    
    // Validate form data
    if (empty($email)) {
        $errors[] = "Email is required";
    }
    
    if (empty($password)) {
        $errors[] = "Password is required";
    }
    
    // If no errors, attempt to log in
    if (empty($errors)) {
        // Get admin from database
        $sql = "SELECT * FROM admins WHERE email = ?";
        $stmt = $conn->prepare($sql);
        $stmt->bind_param("s", $email);
        $stmt->execute();
        $result = $stmt->get_result();
        
        if ($result->num_rows === 1) {
            $admin = $result->fetch_assoc();
            
            // Verify password
            if (password_verify($password, $admin['password'])) {
                // Login successful
                $_SESSION['admin_id'] = $admin['id'];
                $_SESSION['admin_name'] = $admin['name'];
                
                // Set cookie if remember me is checked
                if ($remember) {
                    $token = bin2hex(random_bytes(32));
                    $expires = time() + (86400 * 30); // 30 days
                    
                    // Store token in database
                    $sql = "UPDATE admins SET remember_token = ?, token_expires = FROM_UNIXTIME(?) WHERE id = ?";
                    $stmt = $conn->prepare($sql);
                    $stmt->bind_param("sii", $token, $expires, $admin['id']);
                    $stmt->execute();
                    
                    // Set cookie
                    setcookie('admin_remember_token', $token, $expires, '/');
                }
                
                // Update last login time
                $sql = "UPDATE admins SET last_login = NOW() WHERE id = ?";
                $stmt = $conn->prepare($sql);
                $stmt->bind_param("i", $admin['id']);
                $stmt->execute();
                
                // Redirect to dashboard
                header("Location: dashboard.php");
                exit;
            } else {
                $errors[] = "Invalid email or password";
            }
        } else {
            $errors[] = "Invalid email or password";
        }
    }
}

// Check for remember me cookie
if (!isset($_SESSION['admin_id']) && isset($_COOKIE['admin_remember_token'])) {
    $token = $_COOKIE['admin_remember_token'];
    
    // Get admin with matching token
    $sql = "SELECT * FROM admins WHERE remember_token = ? AND token_expires > NOW()";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("s", $token);
    $stmt->execute();
    $result = $stmt->get_result();
    
    if ($result->num_rows === 1) {
        $admin = $result->fetch_assoc();
        
        // Login admin
        $_SESSION['admin_id'] = $admin['id'];
        $_SESSION['admin_name'] = $admin['name'];
        
        // Update last login time
        $sql = "UPDATE admins SET last_login = NOW() WHERE id = ?";
        $stmt = $conn->prepare($sql);
        $stmt->bind_param("i", $admin['id']);
        $stmt->execute();
        
        // Redirect to dashboard
        header("Location: dashboard.php");
        exit;
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Login - QuizMania</title>
    <link rel="stylesheet" href="../css/style.css">
</head>
<body>
    <header>
        <div class="container">
            <div class="logo">
                <a href="../index.php">QuizMania</a>
            </div>
            <nav>
                <ul>
                    <li><a href="../index.php">Main Site</a></li>
                </ul>
            </nav>
        </div>
    </header>
    
    <main>
        <div class="form-container">
            <h2>Admin Login</h2>
            
            <?php 
            // Display message if set
            echo display_message();
            
            // Display errors
            if (!empty($errors)): 
            ?>
                <div class="alert alert-danger">
                    <ul>
                        <?php foreach ($errors as $error): ?>
                            <li><?php echo $error; ?></li>
                        <?php endforeach; ?>
                    </ul>
                </div>
            <?php endif; ?>
            
            <form action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>" method="post">
                <div class="form-group">
                    <label for="email">Email</label>
                    <input type="email" id="email" name="email" class="form-control" value="<?php echo isset($email) ? $email : ''; ?>" required>
                </div>
                
                <div class="form-group">
                    <label for="password">Password</label>
                    <input type="password" id="password" name="password" class="form-control" required>
                </div>
                
                <div class="form-check">
                    <input type="checkbox" id="remember" name="remember" class="form-check-input">
                    <label for="remember">Remember me</label>
                </div>
                
                <button type="submit" class="form-btn">Login</button>
                
                <div class="form-footer">
                    <a href="register.php">Register as Admin</a>
                </div>
            </form>
        </div>
    </main>
    
    <footer>
        <div class="container">
            <div class="footer-bottom">
                <p>&copy; <?php echo date('Y'); ?> QuizMania. All rights reserved.</p>
            </div>
        </div>
    </footer>
    
    <script src="../js/script.js"></script>
</body>
</html>