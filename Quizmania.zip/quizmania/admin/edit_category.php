<?php
session_start();
require_once '../includes/db_connect.php';
require_once '../includes/functions.php';

// Redirect if not logged in
if (!is_admin_logged_in()) {
    redirect_with_message("login.php", "Please log in to access the admin dashboard", "danger");
}

// Check if category ID is provided
if (!isset($_GET['id']) || empty($_GET['id'])) {
    redirect_with_message("categories.php", "Invalid category ID", "danger");
}

$category_id = intval($_GET['id']);
$errors = [];
$success = false;

// Fetch category details
$sql = "SELECT * FROM categories WHERE id = ?";
$stmt = $conn->prepare($sql);
$stmt->bind_param("i", $category_id);
$stmt->execute();
$result = $stmt->get_result();

if ($result->num_rows === 0) {
    redirect_with_message("categories.php", "Category not found", "danger");
}

$category = $result->fetch_assoc();
$name = $category['name'];
$description = $category['description'];

// Update category
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $name = sanitize_input($_POST['name']);
    $description = sanitize_input($_POST['description']);

    if (empty($name)) {
        $errors[] = "Category name is required";
    } elseif ($name !== $category['name'] && category_exists($conn, $name)) {
        $errors[] = "Category with this name already exists";
    }

    if (empty($description)) {
        $errors[] = "Category description is required";
    }

    if (empty($errors)) {
        $sql = "UPDATE categories SET name = ?, description = ? WHERE id = ?";
        $stmt = $conn->prepare($sql);
        $stmt->bind_param("ssi", $name, $description, $category_id);

        if ($stmt->execute()) {
            $success = true;
        } else {
            $errors[] = "Failed to update category: " . $conn->error;
        }
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Edit Category - QuizMania Admin</title>
    <link rel="stylesheet" href="../css/style.css">
</head>
<body>
    <div class="admin-container">
        <?php include 'includes/sidebar.php'; ?>

        <div class="admin-content">
            <div class="admin-header">
                <h2>Edit Category</h2>
            </div>

            <div class="admin-card">
                <?php if ($success): ?>
                    <div class="alert alert-success">
                        Category updated successfully!
                    </div>
                <?php endif; ?>

                <?php if (!empty($errors)): ?>
                    <div class="alert alert-danger">
                        <ul>
                            <?php foreach ($errors as $error): ?>
                                <li><?php echo $error; ?></li>
                            <?php endforeach; ?>
                        </ul>
                    </div>
                <?php endif; ?>

                <form action="" method="post" class="admin-form">
                    <div class="form-group">
                        <label for="name">Category Name</label>
                        <input type="text" id="name" name="name" class="form-control" value="<?php echo htmlspecialchars($name); ?>" required>
                    </div>

                    <div class="form-group">
                        <label for="description">Category Description</label>
                        <textarea id="description" name="description" class="form-control" rows="4" required><?php echo htmlspecialchars($description); ?></textarea>
                    </div>

                    <button type="submit" class="form-btn">Update Category</button>
                    <a href="categories.php" class="form-btn cancel-btn">Cancel</a>
                </form>
            </div>
        </div>
    </div>

    <script src="../js/script.js"></script>
</body>
</html>
