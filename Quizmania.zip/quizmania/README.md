# QuizMania - Quiz Management System

QuizMania is a comprehensive PHP/MySQL application for creating and managing quizzes. It features separate user and admin interfaces, authentication, quiz management, and detailed reporting.

## Features

### User Side
- User registration and login with session management
- Browse quiz categories
- Customize quiz settings (number of questions, time limit)
- Take quizzes with timer and navigation
- View detailed quiz results
- Track progress in user dashboard

### Admin Side
- Secure admin registration and login
- Dashboard with charts and statistics
- Add and manage quiz categories
- Create and manage quiz questions
- Monitor active users
- View detailed user reports

## Installation

1. Upload all files to your web server
2. Create a MySQL database
3. Update database connection details in `includes/db_connect.php`
4. Run the setup script by visiting `setup.php` in your browser
5. Delete `setup.php` after successful installation

## Admin Setup

1. Visit `admin/register.php` to create the admin account
2. Only one admin account can be created
3. After registration, you'll be redirected to the login page
4. Log in with your admin credentials

## Usage

### For Users
1. Register an account or log in
2. Browse available quiz categories
3. Select a category and customize your quiz
4. Take the quiz and view your results
5. Track your progress in the dashboard

### For Admins
1. Log in to the admin panel
2. Add quiz categories
3. Add questions to categories
4. Monitor user activity
5. View detailed reports

## Technologies Used
- PHP
- MySQL
- JavaScript
- HTML/CSS
- Chart.js for data visualization

## Security Features
- Password hashing
- Session management
- Remember me functionality
- Input sanitization
- Prepared statements to prevent SQL injection

## License
This project is licensed under the MIT License.