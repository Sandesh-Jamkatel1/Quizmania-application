<?php
session_start();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>QuizMania - Home</title>
    <link rel="stylesheet" href="css/style.css">
</head>
<body>
    <?php include 'includes/header.php'; ?>
    
    <main>
        <section class="hero">
            <div class="container">
                <h1>Welcome to QuizMania</h1>
                <p>Test your knowledge with our interactive quizzes</p>
                <div class="hero-buttons">
                    <?php if(isset($_SESSION['user_id'])): ?>
                        <a href="categories.php" class="btn btn-primary">Start Quiz</a>
                        <a href="dashboard.php" class="btn btn-secondary">My Dashboard</a>
                    <?php else: ?>
                        <a href="login.php" class="btn btn-primary">Login</a>
                        <a href="register.php" class="btn btn-secondary">Register</a>
                    <?php endif; ?>
                </div>
            </div>
        </section>

        <section class="features">
            <div class="container">
                <h2>Why Choose QuizMania?</h2>
                <div class="feature-grid">
                    <div class="feature-card">
                        <div class="feature-icon">📚</div>
                        <h3>Multiple Categories</h3>
                        <p>Choose from a variety of quiz categories including HTML, CSS, JavaScript, jQuery, and DSA.</p>
                    </div>
                    <div class="feature-card">
                        <div class="feature-icon">⏱️</div>
                        <h3>Customizable Experience</h3>
                        <p>Set your own time limit and number of questions for a personalized quiz experience.</p>
                    </div>
                    <div class="feature-card">
                        <div class="feature-icon">📊</div>
                        <h3>Track Your Progress</h3>
                        <p>Monitor your performance with detailed statistics and progress reports.</p>
                    </div>
                    <div class="feature-card">
                        <div class="feature-icon">🏆</div>
                        <h3>Challenge Yourself</h3>
                        <p>Improve your skills by taking quizzes repeatedly and beating your previous scores.</p>
                    </div>
                </div>
            </div>
        </section>
    </main>
    
    <?php include 'includes/footer.php'; ?>
    <script src="js/script.js"></script>
</body>
</html>