<?php
session_start();
require_once 'includes/db_connect.php';
require_once 'includes/functions.php';

// Redirect if not logged in
if (!is_user_logged_in()) {
    redirect_with_message("login.php", "Please log in to take a quiz", "danger");
}

// Check if quiz session exists
if (!isset($_SESSION['quiz'])) {
    redirect_with_message("categories.php", "Please select a category to start a quiz", "danger");
}

// Get quiz settings from session
$quiz = $_SESSION['quiz'];
$category_id = $quiz['category_id'];
$category_name = $quiz['category_name'];
$num_questions = $quiz['num_questions'];
$time_limit = $quiz['time_limit'];
$start_time = $quiz['start_time'];

// Calculate remaining time
$elapsed_time = time() - $start_time;
$remaining_time = max(0, $time_limit - $elapsed_time);

// Check if time is up
if ($remaining_time <= 0 && !isset($_POST['submit_quiz'])) {
    // Auto-submit the quiz
    $_POST['submit_quiz'] = true;
}

// Get questions if not already in session
if (!isset($_SESSION['quiz']['questions'])) {
    $questions = get_questions_by_category($conn, $category_id, $num_questions);
    $_SESSION['quiz']['questions'] = $questions;
    
    // Initialize answers array
    $_SESSION['quiz']['answers'] = array_fill(0, count($questions), null);
} else {
    $questions = $_SESSION['quiz']['questions'];
}

// Handle form submission
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Check if quiz is being submitted
    if (isset($_POST['submit_quiz'])) {
        // Calculate score
        $score = 0;
        foreach ($questions as $index => $question) {
            $user_answer = isset($_SESSION['quiz']['answers'][$index]) ? $_SESSION['quiz']['answers'][$index] : null;
            $correct_answer = $question['correct_option'];
            
            if ($user_answer !== null && $user_answer == $correct_answer) {
                $score++;
            }
        }
        
        // Calculate time taken
        $time_taken = min($time_limit, time() - $start_time);
        
        // Record quiz attempt
        record_quiz_attempt($conn, $_SESSION['user_id'], $category_id, $score, count($questions), $time_taken);
        
        // Store results in session
        $_SESSION['quiz_results'] = [
            'category_name' => $category_name,
            'score' => $score,
            'total_questions' => count($questions),
            'time_taken' => $time_taken
        ];
        
        // Clear quiz session
        unset($_SESSION['quiz']);
        
        // Redirect to results page
        header("Location: quiz_results.php");
        exit;
    }
    
    // Check if an answer is being saved
    if (isset($_POST['question_index']) && isset($_POST['answer'])) {
        $question_index = intval($_POST['question_index']);
        $answer = intval($_POST['answer']);
        
        // Save answer
        if ($question_index >= 0 && $question_index < count($questions)) {
            $_SESSION['quiz']['answers'][$question_index] = $answer;
        }
        
        // Redirect to next question if specified
        if (isset($_POST['next_question'])) {
            $next_index = $question_index + 1;
            if ($next_index < count($questions)) {
                header("Location: quiz.php?q=" . $next_index);
            } else {
                header("Location: quiz.php?q=" . $question_index);
            }
            exit;
        }
        
        // Redirect to previous question if specified
        if (isset($_POST['prev_question'])) {
            $prev_index = $question_index - 1;
            if ($prev_index >= 0) {
                header("Location: quiz.php?q=" . $prev_index);
            } else {
                header("Location: quiz.php?q=0");
            }
            exit;
        }
    }
}

// Get current question index
$current_index = isset($_GET['q']) && is_numeric($_GET['q']) ? intval($_GET['q']) : 0;
if ($current_index < 0 || $current_index >= count($questions)) {
    $current_index = 0;
}

// Get current question
$current_question = $questions[$current_index];

// Get options for current question
$options = [
    $current_question['option1'],
    $current_question['option2'],
    $current_question['option3'],
    $current_question['option4']
];

// Get user's answer for current question
$user_answer = isset($_SESSION['quiz']['answers'][$current_index]) ? $_SESSION['quiz']['answers'][$current_index] : null;
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo htmlspecialchars($category_name); ?> Quiz - QuizMania</title>
    <link rel="stylesheet" href="css/style.css">
</head>
<body>
    <?php include 'includes/header.php'; ?>
    
    <main>
        <div class="container">
            <div class="quiz-container">
                <div class="quiz-header">
                    <div class="quiz-progress">
                        Question <?php echo $current_index + 1; ?> of <?php echo count($questions); ?>
                    </div>
                    <div class="quiz-timer" id="timer">
                        Time Remaining: <span id="time-display"><?php echo floor($remaining_time / 60) . ':' . str_pad($remaining_time % 60, 2, '0', STR_PAD_LEFT); ?></span>
                    </div>
                </div>
                
                <form id="quiz-form" action="quiz.php" method="post">
                    <input type="hidden" name="question_index" value="<?php echo $current_index; ?>">
                    
                    <div class="question" data-question-id="<?php echo $current_question['id']; ?>">
                        <h3><?php echo htmlspecialchars($current_question['question_text']); ?></h3>
                        
                        <div class="options">
                            <?php foreach ($options as $index => $option): ?>
                                <div class="option <?php echo $user_answer !== null && $user_answer == $index ? 'selected' : ''; ?>" onclick="selectOption(this)" data-option-value="<?php echo $index; ?>">
                                    <?php echo htmlspecialchars($option); ?>
                                </div>
                            <?php endforeach; ?>
                        </div>
                        
                        <input type="hidden" name="answer" id="selected-answer" value="<?php echo $user_answer !== null ? $user_answer : ''; ?>">
                    </div>
                    
                    <div class="quiz-navigation">
                        <?php if ($current_index > 0): ?>
                            <button type="submit" name="prev_question" class="btn btn-secondary">Previous</button>
                        <?php else: ?>
                            <div></div>
                        <?php endif; ?>
                        
                        <?php if ($current_index < count($questions) - 1): ?>
                            <button type="submit" name="next_question" class="btn btn-primary">Next</button>
                        <?php else: ?>
                            <button type="submit" name="submit_quiz" class="btn btn-primary">Finish Quiz</button>
                        <?php endif; ?>
                    </div>
                </form>
            </div>
        </div>
    </main>
    
    <?php include 'includes/footer.php'; ?>
    <script src="js/script.js"></script>
    <script>
        // Initialize timer
        const timerDisplay = document.getElementById('time-display');
        let remainingTime = <?php echo $remaining_time; ?>;
        
        const timerInterval = setInterval(function() {
            remainingTime--;
            
            if (remainingTime <= 0) {
                clearInterval(timerInterval);
                document.getElementById('quiz-form').submit();
            }
            
            const minutes = Math.floor(remainingTime / 60);
            const seconds = remainingTime % 60;
            timerDisplay.textContent = minutes + ':' + (seconds < 10 ? '0' : '') + seconds;
        }, 1000);
        
        // Function to select an option
        function selectOption(optionElement) {
            // Remove selected class from all options
            const options = document.querySelectorAll('.option');
            options.forEach(option => {
                option.classList.remove('selected');
            });
            
            // Add selected class to clicked option
            optionElement.classList.add('selected');
            
            // Update hidden input value
            document.getElementById('selected-answer').value = optionElement.dataset.optionValue;
        }
    </script>
</body>
</html>