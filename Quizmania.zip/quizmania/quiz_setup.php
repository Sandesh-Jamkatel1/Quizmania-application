<?php
session_start();
require_once 'includes/db_connect.php';
require_once 'includes/functions.php';

// Redirect if not logged in
if (!is_user_logged_in()) {
    redirect_with_message("login.php", "Please log in to take a quiz", "danger");
}

// Check if category ID is provided
if (!isset($_GET['category_id']) || !is_numeric($_GET['category_id'])) {
    redirect_with_message("categories.php", "Invalid category selected", "danger");
}

$category_id = $_GET['category_id'];
$category = get_category_by_id($conn, $category_id);

// Check if category exists
if (!$category) {
    redirect_with_message("categories.php", "Category not found", "danger");
}

// Count total questions in the category
$total_questions = count_questions_in_category($conn, $category_id);

// Handle form submission
$errors = [];

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Get form data
    $num_questions = isset($_POST['num_questions']) ? intval($_POST['num_questions']) : 10;
    $time_limit = isset($_POST['time_limit']) ? intval($_POST['time_limit']) : 10;
    
    // Validate form data
    if ($num_questions <= 0) {
        $errors[] = "Number of questions must be greater than 0";
    } elseif ($num_questions > $total_questions) {
        $errors[] = "Selected number of questions exceeds available questions ($total_questions)";
    }
    
    if ($time_limit <= 0) {
        $errors[] = "Time limit must be greater than 0";
    } elseif ($time_limit > 60) {
        $errors[] = "Time limit cannot exceed 60 minutes";
    }
    
    // If no errors, start the quiz
    if (empty($errors)) {
        // Store quiz settings in session
        $_SESSION['quiz'] = [
            'category_id' => $category_id,
            'category_name' => $category['name'],
            'num_questions' => $num_questions,
            'time_limit' => $time_limit * 60, // Convert to seconds
            'start_time' => time()
        ];
        
        // Redirect to quiz page
        header("Location: quiz.php");
        exit;
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Quiz Setup - <?php echo htmlspecialchars($category['name']); ?> - QuizMania</title>
    <link rel="stylesheet" href="css/style.css">
</head>
<body>
    <?php include 'includes/header.php'; ?>
    
    <main>
        <div class="container">
            <div class="quiz-setup">
                <h2>Setup Your <?php echo htmlspecialchars($category['name']); ?> Quiz</h2>
                
                <?php if (!empty($errors)): ?>
                    <div class="alert alert-danger">
                        <ul>
                            <?php foreach ($errors as $error): ?>
                                <li><?php echo $error; ?></li>
                            <?php endforeach; ?>
                        </ul>
                    </div>
                <?php endif; ?>
                
                <?php if ($total_questions === 0): ?>
                    <div class="alert alert-danger">
                        <p>There are no questions available in this category yet. Please check back later.</p>
                    </div>
                    <a href="categories.php" class="btn btn-primary">Back to Categories</a>
                <?php else: ?>
                    <form action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"] . "?category_id=" . $category_id); ?>" method="post">
                        <div class="form-group">
                            <label for="num_questions">Number of Questions</label>
                            <input type="number" id="num_questions" name="num_questions" class="form-control" min="1" max="<?php echo $total_questions; ?>" value="<?php echo isset($num_questions) ? $num_questions : min(10, $total_questions); ?>" required>
                            <small>Maximum available: <?php echo $total_questions; ?></small>
                        </div>
                        
                        <div class="form-group">
                            <label for="time_limit">Time Limit (minutes)</label>
                            <input type="number" id="time_limit" name="time_limit" class="form-control" min="1" max="60" value="<?php echo isset($time_limit) ? $time_limit : 10; ?>" required>
                        </div>
                        
                        <button type="submit" class="form-btn">Start Quiz</button>
                    </form>
                <?php endif; ?>
            </div>
        </div>
    </main>
    
    <?php include 'includes/footer.php'; ?>
    <script src="js/script.js"></script>
</body>
</html>