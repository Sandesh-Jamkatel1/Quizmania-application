-- Create database
CREATE DATABASE IF NOT EXISTS quizmania;
USE quizmania;

-- Create users table
CREATE TABLE IF NOT EXISTS users (
    id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(100) NOT NULL,
    email VARCHAR(100) NOT NULL UNIQUE,
    password VARCHAR(255) NOT NULL,
    remember_token VARCHAR(100) DEFAULT NULL,
    token_expires DATETIME DEFAULT NULL,
    last_login DATETIME DEFAULT NULL,
    created_at DATETIME NOT NULL,
    updated_at DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
);

-- Create admins table
CREATE TABLE IF NOT EXISTS admins (
    id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(100) NOT NULL,
    email VARCHAR(100) NOT NULL UNIQUE,
    password VARCHAR(255) NOT NULL,
    remember_token VARCHAR(100) DEFAULT NULL,
    token_expires DATETIME DEFAULT NULL,
    last_login DATETIME DEFAULT NULL,
    created_at DATETIME NOT NULL,
    updated_at DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
);

-- Create categories table
CREATE TABLE IF NOT EXISTS categories (
    id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(100) NOT NULL,
    description TEXT NOT NULL,
    created_at DATETIME NOT NULL,
    updated_at DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
);

-- Create questions table
CREATE TABLE IF NOT EXISTS questions (
    id INT AUTO_INCREMENT PRIMARY KEY,
    category_id INT NOT NULL,
    question_text TEXT NOT NULL,
    option1 VARCHAR(255) NOT NULL,
    option2 VARCHAR(255) NOT NULL,
    option3 VARCHAR(255) NOT NULL,
    option4 VARCHAR(255) NOT NULL,
    correct_option TINYINT NOT NULL,
    created_at DATETIME NOT NULL,
    updated_at DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (category_id) REFERENCES categories(id) ON DELETE CASCADE
);

-- Create quiz_attempts table
CREATE TABLE IF NOT EXISTS quiz_attempts (
    id INT AUTO_INCREMENT PRIMARY KEY,
    user_id INT NOT NULL,
    category_id INT NOT NULL,
    score INT NOT NULL,
    total_questions INT NOT NULL,
    time_taken INT NOT NULL,
    attempt_date DATETIME NOT NULL,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
    FOREIGN KEY (category_id) REFERENCES categories(id) ON DELETE CASCADE
);

-- Insert sample categories
INSERT INTO categories (name, description, created_at) VALUES
('HTML', 'Test your knowledge of HTML markup language', NOW()),
('CSS', 'Challenge yourself with Cascading Style Sheets questions', NOW()),
('JavaScript', 'JavaScript programming language quiz', NOW()),
('jQuery', 'Test your jQuery library knowledge', NOW()),
('DSA', 'Data Structures and Algorithms challenges', NOW()),
('PHP', 'PHP programming language quiz', NOW());

-- Insert sample questions for HTML category
INSERT INTO questions (category_id, question_text, option1, option2, option3, option4, correct_option, created_at) VALUES
(1, 'What does HTML stand for?', 'Hyper Text Markup Language', 'High Tech Modern Language', 'Hyper Transfer Markup Language', 'Home Tool Markup Language', 0, NOW()),
(1, 'Which HTML tag is used to define an internal style sheet?', '<style>', '<css>', '<script>', '<link>', 0, NOW()),
(1, 'Which HTML attribute is used to define inline styles?', 'styles', 'style', 'class', 'font', 1, NOW()),
(1, 'Which HTML element is used to specify a header for a document or section?', '<head>', '<header>', '<top>', '<h1>', 1, NOW()),
(1, 'Which HTML element defines navigation links?', '<navigation>', '<nav>', '<navigate>', '<links>', 1, NOW()),
(1, 'Which HTML element is used to specify a footer for a document or section?', '<footer>', '<bottom>', '<section>', '<foot>', 0, NOW()),
(1, 'Which HTML element is used to define an unordered list?', '<ul>', '<ol>', '<li>', '<list>', 0, NOW()),
(1, 'Which HTML element is used to define an ordered list?', '<ul>', '<ol>', '<li>', '<list>', 1, NOW()),
(1, 'Which HTML element is used to define a table?', '<table>', '<tab>', '<tr>', '<grid>', 0, NOW()),
(1, 'Which HTML element is used to define a table row?', '<tr>', '<td>', '<row>', '<th>', 0, NOW());

-- Insert sample questions for CSS category
INSERT INTO questions (category_id, question_text, option1, option2, option3, option4, correct_option, created_at) VALUES
(2, 'What does CSS stand for?', 'Creative Style Sheets', 'Cascading Style Sheets', 'Computer Style Sheets', 'Colorful Style Sheets', 1, NOW()),
(2, 'Which property is used to change the background color?', 'color', 'bgcolor', 'background-color', 'background', 2, NOW()),
(2, 'Which CSS property controls the text size?', 'font-size', 'text-size', 'font-style', 'text-style', 0, NOW()),
(2, 'Which property is used to change the font of an element?', 'font-family', 'font-style', 'font-weight', 'font-size', 0, NOW()),
(2, 'Which CSS property is used to change the text color of an element?', 'color', 'text-color', 'font-color', 'background-color', 0, NOW()),
(2, 'Which CSS property is used to add space between the border and content?', 'margin', 'padding', 'spacing', 'border-spacing', 1, NOW()),
(2, 'Which CSS property is used to add space around elements?', 'margin', 'padding', 'spacing', 'border', 0, NOW()),
(2, 'Which CSS property is used to set the background image?', 'background-image', 'background', 'image', 'src', 0, NOW()),
(2, 'Which CSS property is used to position an element relative to its normal position?', 'position', 'top', 'left', 'relative', 0, NOW()),
(2, 'Which CSS property is used to specify the transparency of an element?', 'transparency', 'opacity', 'filter', 'visibility', 1, NOW());

-- Insert sample questions for JavaScript category
INSERT INTO questions (category_id, question_text, option1, option2, option3, option4, correct_option, created_at) VALUES
(3, 'Inside which HTML element do we put the JavaScript?', '<script>', '<javascript>', '<js>', '<scripting>', 0, NOW()),
(3, 'Where is the correct place to insert a JavaScript?', 'The <head> section', 'The <body> section', 'Both the <head> and <body> sections are correct', 'None of the above', 2, NOW()),
(3, 'What is the correct syntax for referring to an external script called "xxx.js"?', '<script href="xxx.js">', '<script name="xxx.js">', '<script src="xxx.js">', '<script file="xxx.js">', 2, NOW()),
(3, 'How do you write "Hello World" in an alert box?', 'alertBox("Hello World");', 'msg("Hello World");', 'alert("Hello World");', 'msgBox("Hello World");', 2, NOW()),
(3, 'How do you create a function in JavaScript?', 'function myFunction()', 'function:myFunction()', 'function = myFunction()', 'function => myFunction()', 0, NOW()),
(3, 'How do you call a function named "myFunction"?', 'call myFunction()', 'myFunction()', 'call function myFunction()', 'Call.myFunction()', 1, NOW()),
(3, 'How to write an IF statement in JavaScript?', 'if i = 5 then', 'if i == 5 then', 'if (i == 5)', 'if i = 5', 2, NOW()),
(3, 'How to write an IF statement for executing some code if "i" is NOT equal to 5?', 'if (i != 5)', 'if i <> 5', 'if (i <> 5)', 'if i =! 5 then', 0, NOW()),
(3, 'How does a WHILE loop start?', 'while i = 1 to 10', 'while (i <= 10)', 'while (i <= 10; i++)', 'while i = 1 to 10 do', 1, NOW()),
(3, 'How does a FOR loop start?', 'for (i = 0; i <= 5)', 'for (i <= 5; i++)', 'for i = 1 to 5', 'for (i = 0; i <= 5; i++)', 3, NOW());

-- Insert sample questions for jQuery category
INSERT INTO questions (category_id, question_text, option1, option2, option3, option4, correct_option, created_at) VALUES
(4, 'Which sign does jQuery use as a shortcut for jQuery?', '$', '?', '%', '&', 0, NOW()),
(4, 'With jQuery, look at the following selector: $("div"). What does it select?', 'The first div element', 'All div elements', 'All elements with the class div', 'All elements with the ID div', 1, NOW()),
(4, 'With jQuery, look at the following selector: $(".test"). What does it select?', 'All elements with the class "test"', 'The element with the ID "test"', 'All elements with the attribute "test"', 'All <test> elements', 0, NOW()),
(4, 'With jQuery, look at the following selector: $("#test"). What does it select?', 'All elements with the class "test"', 'The element with the ID "test"', 'All elements with the attribute "test"', 'All <test> elements', 1, NOW()),
(4, 'What is the correct jQuery code to set the background color of all p elements to red?', '$("p").style("background-color","red");', '$("p").css("background-color","red");', '$("p").background("red");', '$("p").layout("background-color","red");', 1, NOW()),
(4, 'With jQuery, look at the following selector: $("div.intro"). What does it select?', 'All div elements with class="intro"', 'The first div element with class="intro"', 'All div elements with id="intro"', 'The first div element with id="intro"', 0, NOW()),
(4, 'What is the correct jQuery code for making all div elements 100 pixels high?', '$("div").height="100"', '$("div").height(100)', '$("div").height="100px"', '$("div").height("100px")', 1, NOW()),
(4, 'Which jQuery method is used to hide selected elements?', 'hidden()', 'hide()', 'visible(false)', 'display(none)', 1, NOW()),
(4, 'Which jQuery method is used to set one or more style properties for selected elements?', 'css()', 'style()', 'html()', 'attr()', 0, NOW()),
(4, 'Which jQuery method is used to perform an Ajax request?', 'ajax()', 'ajaxRequest()', 'request()', 'load()', 0, NOW());

-- Insert sample questions for DSA category
INSERT INTO questions (category_id, question_text, option1, option2, option3, option4, correct_option, created_at) VALUES
(5, 'What is the time complexity of binary search?', 'O(n)', 'O(log n)', 'O(n log n)', 'O(n²)', 1, NOW()),
(5, 'Which data structure follows the Last In First Out (LIFO) principle?', 'Queue', 'Stack', 'Linked List', 'Array', 1, NOW()),
(5, 'Which data structure follows the First In First Out (FIFO) principle?', 'Queue', 'Stack', 'Tree', 'Graph', 0, NOW()),
(5, 'What is the worst-case time complexity of quicksort?', 'O(n)', 'O(log n)', 'O(n log n)', 'O(n²)', 3, NOW()),
(5, 'Which of the following is not a linear data structure?', 'Array', 'Linked List', 'Queue', 'Tree', 3, NOW()),
(5, 'What is the time complexity of inserting an element at the end of an array?', 'O(1)', 'O(log n)', 'O(n)', 'O(n²)', 0, NOW()),
(5, 'Which sorting algorithm has the best average-case time complexity?', 'Bubble Sort', 'Insertion Sort', 'Quick Sort', 'Selection Sort', 2, NOW()),
(5, 'What is the space complexity of merge sort?', 'O(1)', 'O(log n)', 'O(n)', 'O(n²)', 2, NOW()),
(5, 'Which data structure is best for implementing a priority queue?', 'Array', 'Linked List', 'Heap', 'Stack', 2, NOW()),
(5, 'What is the time complexity of searching for an element in a hash table?', 'O(1)', 'O(log n)', 'O(n)', 'O(n log n)', 0, NOW());

-- Insert sample questions for PHP category
INSERT INTO questions (category_id, question_text, option1, option2, option3, option4, correct_option, created_at) VALUES
(6, 'What does PHP stand for?', 'Personal Home Page', 'Hypertext Preprocessor', 'Pretext Hypertext Processor', 'Preprocessor Home Page', 1, NOW()),
(6, 'How do you write "Hello World" in PHP?', 'echo "Hello World";', '"Hello World";', 'Document.Write("Hello World");', 'print("Hello World");', 0, NOW()),
(6, 'All variables in PHP start with which symbol?', '!', '$', '&', '#', 1, NOW()),
(6, 'The PHP syntax is most similar to:', 'JavaScript', 'Perl and C', 'VBScript', 'Java', 1, NOW()),
(6, 'How do you get information from a form that is submitted using the "get" method?', '$_GET[]', 'Request.Form', 'Request.QueryString', '$_POST[]', 0, NOW()),
(6, 'When using the POST method, variables are displayed in the URL:', 'True', 'False', 'Only when using HTTPS', 'Only when using GET and POST together', 1, NOW()),
(6, 'Which superglobal variable holds information about headers, paths, and script locations?', '$_GET', '$_POST', '$_SERVER', '$_GLOBALS', 2, NOW()),
(6, 'What is the correct way to create a function in PHP?', 'function myFunction()', 'new_function myFunction()', 'create myFunction()', 'function:myFunction()', 0, NOW()),
(6, 'What is the correct way to open the file "time.txt" as readable?', 'fopen("time.txt","r");', 'open("time.txt","read");', 'fopen("time.txt","read");', 'open("time.txt","r");', 0, NOW()),
(6, 'Which one of these variables has an illegal name?', '$my_var', '$myVar', '$_myvar', '$my-var', 3, NOW());