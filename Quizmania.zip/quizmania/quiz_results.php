<?php
session_start();
require_once 'includes/db_connect.php';
require_once 'includes/functions.php';

// Redirect if not logged in
if (!is_user_logged_in()) {
    redirect_with_message("login.php", "Please log in to view quiz results", "danger");
}

// Check if quiz results exist
if (!isset($_SESSION['quiz_results'])) {
    redirect_with_message("categories.php", "No quiz results found", "danger");
}

// Get quiz results from session
$results = $_SESSION['quiz_results'];
$category_name = $results['category_name'];
$score = $results['score'];
$total_questions = $results['total_questions'];
$time_taken = $results['time_taken'];

// Calculate percentage
$percentage = ($score / $total_questions) * 100;

// Get feedback based on percentage
$feedback = '';
if ($percentage >= 90) {
    $feedback = 'Excellent! You have mastered this category.';
} elseif ($percentage >= 70) {
    $feedback = 'Great job! You have a good understanding of this category.';
} elseif ($percentage >= 50) {
    $feedback = 'Good effort! Keep practicing to improve your knowledge.';
} else {
    $feedback = 'Keep learning! Try again to improve your score.';
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Quiz Results - QuizMania</title>
    <link rel="stylesheet" href="css/style.css">
</head>
<body>
    <?php include 'includes/header.php'; ?>
    
    <main>
        <div class="container">
            <div class="results-container">
                <div class="results-header">
                    <h2><?php echo htmlspecialchars($category_name); ?> Quiz Results</h2>
                    <p><?php echo $feedback; ?></p>
                </div>
                
                <div class="results-stats">
                    <div class="result-stat">
                        <h3>Score</h3>
                        <div class="stat-value"><?php echo $score . '/' . $total_questions; ?></div>
                    </div>
                    
                    <div class="result-stat">
                        <h3>Percentage</h3>
                        <div class="stat-value"><?php echo round($percentage, 2); ?>%</div>
                    </div>
                    
                    <div class="result-stat">
                        <h3>Time Taken</h3>
                        <div class="stat-value"><?php echo format_time_taken($time_taken); ?></div>
                    </div>
                </div>
                
                <div class="results-actions">
                    <a href="categories.php" class="btn btn-primary">Take Another Quiz</a>
                    <a href="dashboard.php" class="btn btn-secondary">Go to Dashboard</a>
                </div>
            </div>
        </div>
    </main>
    
    <?php include 'includes/footer.php'; ?>
    <script src="js/script.js"></script>
</body>
</html>